package com.tuk.tukar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.tuk.tukar.databinding.ActivityGuideBinding


class guide : AppCompatActivity() {
    private lateinit var binding: ActivityGuideBinding
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGuideBinding.inflate(layoutInflater)
        setContentView(binding.root)

            binding.imageView13.setOnClickListener {
                val intent = Intent(this, guide_tip::class.java)
                startActivity(intent)
            }

    }
}